bolttools
=========

This repository contains the code behind the BOLTS library. For more information about BOLTS, see

http://jreinhardt.github.io/BOLTS/index.html

and

https://github.com/jreinhardt/BOLTS

Dependencies
------------

YAML: http://pyyaml.org/
Graphviz: http://graphviz.org

License
-------

This project is published under the GNU Lesser General Public License Version 2.1 or later.
